function [Ix,Iy,Idiag45,Idiag135] = srmImGrad8(I,W1)%8-connectivity

W2=1-W1;
Ix=zeros(size(I));Iy=zeros(size(I));Ix0=Ix;Iy0=Iy;%x-der. and y-der. of I
IxL=Ix;IxR=Ix;IyU=Iy;IyD=Iy;
SOBx=[-1,0,1;-2,0,2;-1,0,1]/8;SOBy=SOBx';%Sobel=[-1,9,-45,0,45,-9,1]/60
for i=1:size(I,3)% Compute image gradient
    Ix0(:,:,i)=imfilter(I(:,:,i),SOBx,'replicate');%sob
    tI=I(:,:,i);tIxL=imfilter(tI,[-1,1,0],'replicate');
    tIxL(:,1)=tI(:,2)-tI(:,1);%As the left derivative of the 1st column.
    IxL(:,:,i)=tIxL;
    tIxR=imfilter(tI,[0,-1,1],'replicate');
    tIxR(:,end)=tI(:,end)-tI(:,end-1);%As the right der. of the last col.
    IxR(:,:,i)=tIxR;
    Iy0(:,:,i)=imfilter(I(:,:,i),SOBy,'replicate');%sob'
    tIyU=imfilter(tI,[-1,1,0]','replicate');
    tIyU(1,:)=tI(2,:)-tI(1,:);%As the up derivative of the 1st column.
    IyU(:,:,i)=tIyU;
    tIyD=imfilter(tI,[0,-1,1]','replicate');
    tIyD(end,:)=tI(end,:)-tI(end-1,:);%As the right der. of the last col.
    IyD(:,:,i)=tIyD;
end
Ix=max(W1*abs(Ix0)+W2*(abs(IxL)+abs(IxR))/2,[],3);
Iy=max(W1*abs(Iy0)+W2*(abs(IyU)+abs(IyD))/2,[],3);%Iy=max(abs(Iy),[],3);

[m,n,k]=size(I);Idiag45=zeros([m,n,k]);%Derivative of 45 degree direction
Idiag45U=Idiag45;Idiag45D=Idiag45;Sob45=Idiag45;
Idiag135=Idiag45;%Derivative of 135 degree direction
Idiag135U=Idiag135;Idiag135D=Idiag135;Sob135=Idiag135;

for i=1:(m-1),
    for j=1:(n-1),
       Idiag45U(i,j,:)=abs(I(i+1,j+1,:)-I(i,j,:));%Der of up right di.
        if i>1 & j>1,
       Idiag45D(i,j,:)=abs(I(i,j,:)-I(i-1,j-1,:));%Der of down left
       Sob45(i,j,:)=abs(2*(I(i+1,j+1,:)-I(i-1,j-1,:))+I(i,j+1,:)...
           -I(i-1,j,:)+I(i+1,j,:)-I(i,j-1,:))/6;
        else,
           Idiag45D(i,j,:)=Idiag45U(i,j,:); Sob45(i,j,:)=Idiag45U(i,j,:);
        end
     Idiag45(i,j,:)=W1*Sob45(i,j,:)+W2*(Idiag45U(i,j,:)+Idiag45D(i,j,:))/2;
    end
end
Idiag45=Idiag45/sqrt(2);

for i=2:m,
    for j=1:(n-1),
       Idiag135U(i,j,:)=abs(I(i-1,j+1,:)-I(i,j,:));%Der of up right di.
        if i<m & j>1,
       Idiag135D(i,j,:)=abs(I(i+1,j-1,:)-I(i,j,:));%Der of down left
       Sob135(i,j,:)=abs(2*(I(i-1,j+1,:)-I(i+1,j-1,:))+I(i,j+1,:)...
           -I(i+1,j,:)+I(i-1,j,:)-I(i,j-1,:))/6;
        else,
           Idiag135D(i,j,:)=Idiag135U(i,j,:); Sob135(i,j,:)=Idiag135U(i,j,:);
        end
     Idiag135(i,j,:)=W1*Sob135(i,j,:)+W2*(Idiag135U(i,j,:)+Idiag135D(i,j,:))/2;
    end
end
Idiag135=Idiag135/sqrt(2);
