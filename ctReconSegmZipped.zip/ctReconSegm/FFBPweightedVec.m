% Copyright (c)
% https://github.com/kk17m/CT-Fan-beam-FBP-reconstruction
function [ReconstIm,proj,ReconstHexImVec,L,sino,InterpIm]=...
FFBPweightedVec(Ah,Bh,Hvec,OutSz,D,RotAns,DetAns,totalA,FanAn,wt,Filt,X,Y);

L=size(Hvec,1);detectorNum=length(DetAns);RotMat=[0,-1;1,0];imL=OutSz;
SOD=D;SDD=1.6*D;p1Source=[-SOD,0]*RotMat;p2Det=zeros(detectorNum,2);
detPosX=SDD*cos(DetAns)-SOD;detPosY=SDD*sin(DetAns);voxel=1;beta=RotAns;
for ii=1:detectorNum, 
    p2Det(ii,1)=detPosX(ii,1);p2Det(ii,2)=detPosY(ii,1);
end
p2Det=p2Det*RotMat;Xplane=(-imL/2:1:(imL-1)/2)+1/2;
InterpFun=scatteredInterpolant(Bh,Ah,Hvec,'natural','none');%lin
InterpIm=InterpFun(X,Y);
numRot=length(RotAns);sino=zeros(numRot,detectorNum);xmax=max(Xplane);
for ii=1:numRot
    p1_x=p1Source(1)*cos(RotAns(ii))-p1Source(2)*sin(RotAns(ii));
    p1_y=p1Source(1)*sin(RotAns(ii))+p1Source(2)*cos(RotAns(ii));
    for jj=1:detectorNum,% the two points rotate
        p2_x=p2Det(jj,1)*cos(RotAns(ii))-p2Det(jj,2)*sin(RotAns(ii));
        p2_y=p2Det(jj,1)*sin(RotAns(ii))+p2Det(jj,2)*cos(RotAns(ii));
        vecP1P2=[p2_x,p2_y]-[p1_x,p1_y];dP1P2=norm(vecP1P2);
        unitVec=vecP1P2/dP1P2;numRayPoints=floor(dP1P2/voxel)+1;
        rayPoints=zeros(numRayPoints,2);ttVec=[];
        for ti=1:numRayPoints,
            tt0=[p1_x,p1_y]+(ti-1)*voxel*unitVec;
            if abs(tt0(1,1))<=xmax & abs(tt0(1,2))<=xmax,
                ttVec=[ttVec;tt0(1,1),tt0(1,2)];
            end
        end
        if size(ttVec,1)>0,
            rayPtsImVals=InterpFun(ttVec(:,1),ttVec(:,2));
        rayPtsImVals(isnan(rayPtsImVals))=0;rayPtsImVals(rayPtsImVals<0)=0;       
            sino(ii,jj)=sino(ii,jj)+sum(rayPtsImVals);
        end
    end%for jj=1:detectorNum
end%for ii=1:numRot

proj=sino';NdetAn=length(DetAns);Nproj=length(RotAns);
BpParkAn=linspace(0,degtorad(totalA),Nproj);FanAnRd=degtorad(FanAn);   
if strcmp(lower(wt),'differential'),%Differential wt
    mat = zeros(NdetAn,Nproj);
    for i = 1:Nproj,
        Bi=beta(i);
      for j = 1:NdetAn,
        if Bi >= 0 & Bi < 2*(FanAnRd/2 + DetAns(j))
            mat(j,i) = Bi/(2*(FanAnRd/2 + DetAns(j)));
elseif Bi>=(2*(DetAns(j)+FanAnRd/2))&Bi<(pi+2*DetAns(j))
            mat(j,i) = 1;
elseif Bi>=(pi+2*DetAns(j))&Bi<=(pi+FanAnRd)
mat(j,i)=(pi+FanAnRd-Bi)/(2*(FanAnRd/2-DetAns(j)));
        else
            mat(j,i) = 0;
        end
      end
    end
    mat=3.*mat.^2-2.*mat.^2;
elseif strcmp(lower(wt),'parker'),%Parker wt
    mat = zeros(NdetAn,Nproj);
    for i = 1:Nproj
      for j = 1:NdetAn
        if BpParkAn(i)>=0&BpParkAn(i) <= 2*(FanAnRd/2-DetAns(j))
mat(j,i)=(sin((pi/4)*(BpParkAn(i)/((FanAnRd/2-DetAns(j))))))^2;
elseif BpParkAn(i)>=2*(FanAnRd/2-DetAns(j))&BpParkAn(i)<=(pi-2*DetAns(j))
            mat(j,i) = 1;
elseif BpParkAn(i)>=(pi-2*DetAns(j))&BpParkAn(i)<=(pi+FanAnRd)
mat(j,i)=(sin((pi/4)*((pi+FanAnRd-BpParkAn(i))/(FanAnRd/2+DetAns(j)))))^2;
        else
            mat(j,i) = 0;
        end
      end
    end
else
    disp('Incorrect wt choice, choose either parker or differential');
end
mat(isnan(mat))=0;pad(1,1:Nproj)=1;DTA=DetAns*pad;
FanSensorSp=DetAns(2)-DetAns(1);proj=proj.*mat;extra=2;
[Nreq,Filter]=filterProjections(proj,Filt,DTA,SOD,SDD,FanSensorSp,extra);
ReconstIm=zeros(OutSz,OutSz);minDetAns=min(DetAns);maxDetAns=max(DetAns);
dAng=DetAns(2,1)-DetAns(1,1);
padedAngs=DetAns(length(DetAns),1)+dAng*[1:extra]';
DetAns=[DetAns;padedAngs];
for ii = 1:OutSz,
    for jj = 1:OutSz,
        xi=X(ii,jj);yj=Y(ii,jj);[phi_c,r_c]=cart2pol(xi,yj);       
for kk=1:Nproj,
    Beta_c=beta(1,kk);BetaMinusPhi=Beta_c-phi_c;%D=SOD
    L2xyBeta=(r_c)^2+(SOD)^2+2*r_c*SOD*sin(BetaMinusPhi);
    gammaPrime=atan(r_c*cos(BetaMinusPhi)/(SOD+r_c*sin(BetaMinusPhi)));
    if gammaPrime>=minDetAns & gammaPrime<=maxDetAns,
    QbetaGamma=interp1(DetAns,Filter(:,kk),gammaPrime,'pchip');
    ReconstIm(ii,jj)=ReconstIm(ii,jj)+QbetaGamma/L2xyBeta;
    end
end 
    end
end
DeltaBeta=beta(2)-beta(1);ReconstIm=2*DeltaBeta*ReconstIm;

ReconstHexImVec=zeros(size(Ah));
minDetAns=min(DetAns);maxDetAns=max(DetAns);
for ii = 1:L,
    xi=Bh(ii);yj=Ah(ii);[phi_c,r_c]=cart2pol(xi,yj);
    for kk=1:Nproj,
        Beta_c=beta(1,kk);BetaMinusPhi=Beta_c-phi_c;%D=SOD
        L2xyBeta=(r_c)^2+(SOD)^2+2*r_c*SOD*sin(BetaMinusPhi);
        gammaPrime=atan(r_c*cos(BetaMinusPhi)/(SOD+r_c*sin(BetaMinusPhi)));
        if gammaPrime>=minDetAns & gammaPrime<=maxDetAns,
            QbetaGamma=interp1(DetAns,Filter(:,kk),gammaPrime,'pchip');
            ReconstHexImVec(ii)=ReconstHexImVec(ii)+QbetaGamma/L2xyBeta;
        end
    end
end
ReconstHexImVec=2*DeltaBeta*ReconstHexImVec;