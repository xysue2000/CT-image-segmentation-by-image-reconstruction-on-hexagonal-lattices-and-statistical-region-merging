function gammaRad = ...
    formGammaVectorPara2fanZ(ploc,d,fanSpacing,fanSensorGeometry);

plocMax = max(ploc);plocMin = min(ploc);%m=length(ploc);
if strcmp(fanSensorGeometry,'line')
    floc = formVectorCenteredOnZero(fanSpacing,plocMin,plocMax);
    % floc represents linear spacing along the line perpendicular to central beam
    % so the set of angles gammaRad must be calculated using ATAN.    
    gammaRad = atan(floc/d); 
else  
    gammaRad =...
formVectorCenteredOnZero(fanSpacing*pi/180,asin(plocMin/d),asin(plocMax/d));  
end