function [A,m] = padToOddDim(A);
[m,n] = size(A);% make projections odd m-dimension for symmetry
if mod(m,2) == 0
    A=[zeros(1,n);A];
end
A=[zeros(1,n);A;zeros(1,n)];m=size(A,1);%pad to have a good boundary