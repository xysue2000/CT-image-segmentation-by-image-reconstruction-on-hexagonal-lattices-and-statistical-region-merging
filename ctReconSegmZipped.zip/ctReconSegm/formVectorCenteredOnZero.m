function vec = formVectorCenteredOnZero(delta,minVal,maxVal)
vec = [fliplr(0:-delta:minVal) delta:delta:maxVal];