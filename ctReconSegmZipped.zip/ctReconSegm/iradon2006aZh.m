function [img,H] = iradon2006aZh(varargin);

[p,theta,filter,d,interp,n] = parse_inputs(varargin{:});
%p=Randon; corr. sq. image sz is n by n; d<=1, cropping fropping frequency
%interp is in {'nearest neighbor','linear','spline','pchip','cubic','v5cubic'}
%filter is in {'ram-lak','shepp-logan','cosine','hamming', 'hann'};
len=size(p,1);H = designFilter(filter, len, d);
p(length(H),1)=0;  % Zero pad projections 
p = fft(p);    % p holds fft of projections
for i = 1:size(p,2)
   p(:,i) = p(:,i).*H; % frequency domain filtering
end
p = real(ifft(p));% p is the filtered projections
p(len+1:end,:) = [];% Truncate the filtered projections
img = zeros(n,class(p));% Allocate memory for the image.
r=n/2-0.5;x=(-r):r;%x=(-Nhalf):(Nhalf-1);
[x,y]=meshgrid(x);
costheta = cos(theta);sintheta = sin(theta);
ctrIdx = ceil(len/2);
imgDiag = 2*ceil(n/sqrt(2))+1;%largest distance through image.
if size(p,1) < imgDiag 
   rz = imgDiag - size(p,1);  % how many rows of zeros
   p = [zeros(ceil(rz/2),size(p,2)); p; zeros(floor(rz/2),size(p,2))];
   ctrIdx = ctrIdx+ceil(rz/2);
end

switch interp
    case 'nearest neighbor'
      for i=1:length(theta)   
          proj = p(:,i);t=round(x*costheta(i) + y*sintheta(i));
          img=img + proj(t+ctrIdx);
      end
  case 'linear'
    for i=1:length(theta)  
        proj=p(:,i);t=x.*costheta(i) + y.*sintheta(i); 
        a=floor(t);img=img+(t-a).*proj(a+1+ctrIdx)+(a+1-t).*proj(a+ctrIdx);
    end 
  case {'spline','pchip','cubic','v5cubic'}
    interp_method = sprintf('*%s',interp); 
    for i=1:length(theta)
        proj=p(:,i);taxis=(1:size(p,1))-ctrIdx;
        t = x.*costheta(i) + y.*sintheta(i);
        projContrib = interp1(taxis,proj,t(:),interp_method);
        img = img + reshape(projContrib,n,n);
    end
end
img = img*pi/(2*length(theta));

function [p,theta,filter,d,interp,n] = parse_inputs(varargin);
if nargin<2
   eid = sprintf('Images:%s:tooFewInputs',mfilename);
   msg = 'Invalid input arguments.';
   error(eid,'%s',msg);
end
p=varargin{1};theta=pi*varargin{2}/180;

% Default values
n = 0;                 % Size of the reconstructed image
d = 1;                 % Defaults to no cropping of filters frequency response
filter = 'ram-lak';    % The ramp filter is the default
interp = 'linear';     % default interpolation is linear
string_args = {'nearest neighbor', 'linear', 'spline', 'pchip', 'cubic', 'v5cubic', ...
      'ram-lak','shepp-logan','cosine','hamming', 'hann'};
%interp is in {'nearest neighbor','linear','spline','pchip','cubic','v5cubic'}
%filter is in {'ram-lak','shepp-logan','cosine','hamming', 'hann'};
for i=3:nargin
   arg = varargin{i};
   if ischar(arg)
      idx = strmatch(lower(arg),string_args);
      if isempty(idx)
         eid = sprintf('Images:%s:unknownInputString',mfilename);
         msg = sprintf('Unknown input string: %s.', arg);
         error(eid,'%s',msg);
      elseif numel(idx) > 1
         eid = sprintf('Images:%s:ambiguousInputString',mfilename);
         msg = sprintf('Ambiguous input string: %s.', arg);
         error(eid,'%s',msg);
      elseif numel(idx) == 1
         if idx <= 6   % It is the interpolation
            interp = string_args{idx};
         elseif (idx > 6) && (idx <= 11)
            filter = string_args{idx};
         end
      end
   elseif numel(arg)==1
      if arg <=1
         d = arg;
      else
         n = arg;
      end
   else
      eid = sprintf('Images:%s:invalidInputParameters',mfilename);
      msg = 'Invalid input parameters';
      error(eid,'%s',msg);
   end
end
if n==0    
   n = 2*floor( size(p,1)/(2*sqrt(2)) );
end
if isempty(theta)
   theta = pi / size(p,2);
end
if numel(theta)==1
   theta = (0:(size(p,2)-1))* theta;
end
if length(theta) ~= size(p,2)
   eid = sprintf('Images:%s:thetaNotMatchingProjectionNumber',mfilename);
   msg = 'THETA does not match the number of projections.';
   error(eid,'%s',msg);
end