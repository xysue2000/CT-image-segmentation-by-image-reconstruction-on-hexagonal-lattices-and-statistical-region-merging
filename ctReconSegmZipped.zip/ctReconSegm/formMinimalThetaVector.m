function theta = formMinimalThetaVector(n,dthetaDeg,gammaMin,gammaMax)

fd=n*180*eps;%fudge=n*180*eps;
theta=formVectorCenteredOnZero(dthetaDeg,-gammaMax+fd,180-gammaMin-fd);
theta=[min(theta)-dthetaDeg theta max(theta)+dthetaDeg];