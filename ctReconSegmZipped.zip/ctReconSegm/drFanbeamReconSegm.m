close all;clear all;clc;
[filename,pathname] =...
uigetfile({'*.*';'*.jpg';'*.jpeg';'*.bmp';'*.tif';'*.gif';'*.png'});
Iin = imread([pathname,filename]);%phantom('Modified Shepp-Logan',imL);
Iin=double(Iin);ctImF1=double(Iin(:,:,1));%[m,n]=size(ctImF1);
imL=512;m=imL;n=imL;sic=(imL+1)/2;
origIm=imresize(ctImF1,[imL,imL],'bilinear');origIm=origIm-min(origIm(:));
origIm=255*origIm/max(origIm(:));%origIm=100*origIm/mean(origIm(:));
figure(1),imagesc(origIm);title('Input image for simulating CT recon.');
AngStep=1;theta=0:AngStep:(180-AngStep);
FanAn=120;totalA=180+FanAn;halfFanAng=FanAn/2;startAng=-halfFanAng;
RotAns=degtorad(startAng:AngStep:(totalA+startAng));
DetAns=-(halfFanAng-AngStep):AngStep:(halfFanAng-AngStep);%Gamma
DetAns=degtorad(DetAns');
SOD=(imL/2)*sqrt(2)/sind(FanAn/2);%SOD: distance of source to center
SOD=ceil(1.2*SOD);SDD=1.6*SOD;voxel=1;%SDD: distance of source to detector
%To compare square lattices with hex lattices fairly, the following
%functiom resample the inputIm to a randomized grid. Then the image on the
%randomized grid is resampled to the sauare lattive and hexagonal lattice
[Svec,Hvec,Av,Bv,Ah,Bh,S_Sq,SqIndVec,SqIJ2C,HexIndVec,HexIJ2C,mHex,...
    nHex,CenteredA,CenteredB,X,Y]=imResample(origIm,imL);
figure(2),imagesc(S_Sq);title('Input image for simulating CT recon.');
inputIm=S_Sq;IntMd='pchip';%linear
cutCoef=0.2;Filt='shepp-logan';%ram-lak
% wt='Parker';%'Parker' or 'differential'
% %Fanbean image reconstruction by formula with Parker or different. weight;
% %inputs Av,Bv,and Svec are vectors representing an image on a squ. lattice
% %the output is a square image defined on a square lattice
% disp('Reconstruction by vectors & formula on Sq lattice');
% [reconSqFM,projSqFM,ReconstSqImVec,LSqVec]=...
% FFBPweightedVec(Av,Bv,Svec,imL,SOD,RotAns,DetAns,totalA,FanAn,wt,Filt,X,Y);
% if min(min(reconSqFM))<0,
% reconSqFM=reconSqFM-cutCoef*min(min(reconSqFM));
% reconSqFM=max(reconSqFM,0);end
% figure(3),imagesc(reconSqFM);
% title('Reconst. im by vectors & formula on Sq lattice');
% 
% %Fanbean image reconstruction by formula with Parker or different. weight;
% %inputs Ah,Bh,and Hvec are vectors representing an image on a hex lattice
% disp('Reconstruction by vectors & formula on Hex lattice');
% [reconHexFM,projHexFM,ReconstHexImVec,LhexVec]=...
% FFBPweightedVec(Ah,Bh,Hvec,imL,SOD,RotAns,DetAns,totalA,FanAn,wt,Filt,X,Y);
% if min(min(reconHexFM))<0,
% reconHexFM=reconHexFM-cutCoef*min(min(reconHexFM));
% reconHexFM=max(reconHexFM,0);end
% figure(4),imagesc(reconHexFM);
% title('Reconst. im by formula & hex lattice');

disp('Reconstruction by rebinning & sq. lattice & vector input.');
FanCov='minimal';%FanCoverage: cycle or minimal; Default value: cycle 
ParaCov='halfcycle';%ParallelCoverage
%Algorithm for the conversion from fan-beams to parallel-beams 
RsVec=radonVec2(Av,Bv,Svec,imL,theta);%iradon, vectors as the input image
FsVec=para2fanZ(RsVec,SOD,1,1,'arc',FanCov,ParaCov,IntMd);%Sq lattice
PsVec=fan2paraZ(FsVec,SOD,1,1,'arc',IntMd,FanCov,1,ParaCov);%Sq lattice

%Fanbean image reconstruction by rebinning to parallel beams;
%the output tildeSvec is a vector representing an image on a squ. lattice
tildeSvec=iradonVec2(PsVec,theta,Filt,1,IntMd,imL,Bv,Av);%iradon: vector inp
if min(tildeSvec)<0,% cutCoef=0.2;
tildeSvec=tildeSvec-cutCoef*min(tildeSvec);tildeSvec=max(tildeSvec,0);end
tildeSvecSq=griddata(Bv,Av,tildeSvec,X,Y,'linear');%Resamp to sq im to displ
tildeSvecSq(isnan(tildeSvecSq))=0;tildeSvecSq=max(tildeSvecSq,0);
figure(5),imagesc(tildeSvecSq);
title('ReconstIm by rebinning & sq. lattice & vector input.');

disp('Reconstruction by rebinning & Hex. lattice & vector input.');
%Algorithm for the conversion from fan-beams to parallel-beams
RhVec=radonVec2(Ah,Bh,Hvec,imL,theta);%iradon for hexagonal lattice
FhVec=para2fanZ(RhVec,SOD,1,1,'arc',FanCov,ParaCov,IntMd);%Hex lattice
PhVec=fan2paraZ(FhVec,SOD,1,1,'arc',IntMd,FanCov,1,ParaCov);%Hex lattice

%Fanbean image reconstruction by rebinning to parallel beams;
%the output tildeHvec is a vector representing an image on a hex lattice
tildeHvec=iradonVec2(PhVec,theta,Filt,1,IntMd,imL,Bh,Ah);
if min(tildeHvec)<0,
tildeHvec=tildeHvec-cutCoef*min(tildeHvec);tildeHvec=max(tildeHvec,0);end
maxtildeHvec2=max(max(tildeHvec))
tildeHrVecSq=griddata(Bh,Ah,tildeHvec,X,Y,'linear');%Resampling for display
tildeHrVecSq(isnan(tildeHrVecSq))=0;tildeHrVecSq=max(tildeHrVecSq,0);
figure(6),imagesc(tildeHrVecSq);
title('ReconstIm by rebinning & hex. lattice ');
% % if min(min(reconSqFM))<0,
% % reconSqFM=reconSqFM-cutCoef*min(min(reconSqFM));
% % reconSqFM=max(reconSqFM,0);end
% % if min(min(reconHexFM))<0,
% % reconHexFM=reconHexFM-cutCoef*min(min(reconHexFM));
% % reconHexFM=max(reconHexFM,0);end

disp('Pearson correlation coefficient: the bigger the better');
% coFormulaSqVec=corr2(inputIm,reconSqFM);%SqLattice by formulaRecon
% coFormulaHex=corr2(inputIm,reconHexFM);%HexLattice by formulaRecon
coSqVec=corr2(Svec,tildeSvec);%SqLattice by rebinning
coHexVec=corr2(Hvec,tildeHvec);%HexLattice by rebinning
% disp(strcat('CoByFormulaOnSqL is:',num2str(coFormulaSqVec)));
% disp(strcat('CoByFormulaOnHexL is:',num2str(coFormulaHex)));
disp(strcat('CoByRebinOnSqL is:',num2str(coSqVec)));
disp(strcat('CoByRebinOnHexL is:',num2str(coHexVec)));
imN=zeros(imL,imL,3);imN(:,:,1)=tildeSvecSq;%reconSqFM;
imN(:,:,2)=tildeSvecSq;imN(:,:,3)=tildeSvecSq;
nPixels=length(Hvec);
HexIm=zeros(nPixels,3);
HexIm(:,1)=tildeHvec;HexIm(:,2)=tildeHvec;HexIm(:,3)=tildeHvec;%para
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%inputIm=imN;g=256;minSZ=3;
W1=0.4;g=256;minSZ=3;Qlevels=2.^(6:-1:0);nQ=length(Qlevels);%Q small few segs
[imgsSegmentd,nClassesL4,time,numEdges,szSegmsQs]...
=srm4(imN,Qlevels,g,minSZ,W1);%Segmentat. using sq. lattices with 4-connec.
timeOfSegmBy4Conne=time;numEdgesBy4Conne=numEdges;titleFtSz=11;
tI=imgsSegmentd{nQ};
figure(7),df4ConneNorm1=zeros(1,nQ-1);df4ConneNorm2=zeros(1,nQ-1);
for k=2:nQ,
    tI=imgsSegmentd{k};subplot(3,2,k-1),imagesc(uint8(tI));axis off;
   tiHH=title([strcat('Q=',num2str(Qlevels(k)),...
      ', 4-connec: ','{ }', num2str(nClassesL4(k)),' segms')]);
   set(tiHH,'FontSize',titleFtSz);tI=tI(:,:,1);
end
Qpos1=1;outputIm1=imgsSegmentd{Qpos1};outputNum1=nClassesL4(Qpos1);
Qpos1N=nQ;outputIm1N=imgsSegmentd{Qpos1N};outputNum1N=nClassesL4(Qpos1N);
[imgsSegmentd,nClassesL8,time,numEdges,szSegmsQs]...
=srm8(imN,Qlevels,g,minSZ,W1);%Segmentat. using sq. lattices with 8-connec.
timeOfSegmBy8Conne=time;numEdgesBy8Conne=numEdges;tI=imgsSegmentd{nQ};
df8ConneNorm1=zeros(1,nQ-1);df8ConneNorm2=zeros(1,nQ-1);
outputIm2=imgsSegmentd{Qpos1};outputNum2=nClassesL8(Qpos1);
outputIm2N=imgsSegmentd{Qpos1N};outputNum2N=nClassesL8(Qpos1N);
figure(8),
for k=2:nQ
    tI=imgsSegmentd{k};
    subplot(3,2,k-1),imagesc(uint8(tI));axis off;
    tiHH=title([strcat('Q=',num2str(Qlevels(k)),...
        ', 8-connec: ','{ }', num2str(nClassesL8(k)),' segms')]);
    set(tiHH,'FontSize',titleFtSz);tI=tI(:,:,1);
end

[hexImgsSegmentd,nClassesHex,time,numEdges,szSegmsQs]=...
srmHex(HexIm,Qlevels,g,minSZ,W1,mHex,nHex);%Segmentat. using hex. lattices
timeOfSegmByHexConne=time;numEdgesByHexConne=numEdges;
tI=hexImgsSegmentd{nQ};HexIm1=Hvec;%HexIm;%/mean(mean(mean(HexIm)));
tic
for k=1:nQ,
    imFinal=zeros(m,n,3);imFinalHex=hexImgsSegmentd{k};
ImSq1=griddata(CenteredB,CenteredA,imFinalHex(:,1),X,Y);
ImSq1(isnan(ImSq1))= 0;
ImSq2=griddata(CenteredB,CenteredA,imFinalHex(:,2),X,Y);
ImSq2(isnan(ImSq2))= 0;
ImSq3=griddata(CenteredB,CenteredA,imFinalHex(:,3),X,Y);
ImSq3(isnan(ImSq3))= 0;
imFinal(:,:,1)=ImSq1;imFinal(:,:,2)=ImSq2;imFinal(:,:,3)=ImSq3;
imgsSegmentd{k}=imFinal;
end%figure(c+1),imagesc(uint8(imFinal));
timeHexResamp=toc
outputIm3=imgsSegmentd{Qpos1};outputNum3=nClassesHex(Qpos1);
outputIm3N=imgsSegmentd{Qpos1N};outputNum3N=nClassesHex(Qpos1N);

figure(9),dfHexConneNorm1=zeros(1,nQ-1);dfHexConneNorm2=zeros(1,nQ-1);
for k=2:nQ,
    tI=imgsSegmentd{k};subplot(3,2,k-1),imagesc(uint8(tI));axis off;
    tiHH=title([strcat('Q=',num2str(Qlevels(k)),...
        ', Hex:','{ }', num2str(nClassesHex(k)),' segms')]);
    set(tiHH,'FontSize',titleFtSz);
end

figure(10),
subplot(2,2,1),imagesc(uint8(imN));axis off;
hh=title('The input image');set(hh,'FontSize',titleFtSz);
subplot(2,2,2),imagesc(uint8(outputIm1));axis off;
hh=title([strcat('Q=',num2str(Qlevels(Qpos1)),', 4-connec: ','{ }', ...
    num2str(outputNum1),' segms')]);
set(hh,'FontSize',titleFtSz);
subplot(2,2,3),imagesc(uint8(outputIm2));axis off;
hh=title([strcat('Q=',num2str(Qlevels(Qpos1)),', 8-connec: ','{ }', ...
    num2str(outputNum2),' segms')]);
set(hh,'FontSize',titleFtSz);
subplot(2,2,4),imagesc(uint8(outputIm3));axis off;
hh=title([strcat('Q=',num2str(Qlevels(Qpos1)),', Hex-connec: ','{ }', ...
    num2str(outputNum3),' segms')]);
set(hh,'FontSize',titleFtSz);

figure(11),
subplot(2,2,1),imagesc(uint8(S_Sq));axis off;
hh=title('The input image');set(hh,'FontSize',titleFtSz);
subplot(2,2,2),imagesc(uint8(outputIm1N));axis off;
hh=title([strcat('Q=',num2str(Qlevels(Qpos1N)),', 4-connec: ','{ }', ...
    num2str(outputNum1N),' segms')]);
set(hh,'FontSize',titleFtSz);
subplot(2,2,3),imagesc(uint8(outputIm2N));axis off;
hh=title([strcat('Q=',num2str(Qlevels(Qpos1N)),', 8-connec: ','{ }', ...
    num2str(outputNum2N),' segms')]);
set(hh,'FontSize',titleFtSz);
subplot(2,2,4),imagesc(uint8(outputIm3N));axis off;
hh=title([strcat('Q=',num2str(Qlevels(Qpos1N)),', Hex-connec: ','{ }', ...
    num2str(outputNum3N),' segms')]);
set(hh,'FontSize',titleFtSz);

% Segment a sample 2D image into 3 classes using fuzzy c-means algorithm.
im=imN;im=im(:,:,1);im=im-min(min(im));im=255*im/max(max(im));im=uint8(im);
numComponents=11;%outputNum3
[C,U,LUT,H]=FastFCMeans(im,numComponents);Umap=FM2map(im,U,H);
figure(12),subplot(3,4,1), imshow(im);
set(get(gca,'Title'),'String','The input image');
for i=1:numComponents,
    subplot(3,4,i+1), 
    imshow(Umap(:,:,i))
    ttl=sprintf('Segmented Class %d',i);
    set(get(gca,'Title'),'String',ttl)
end
