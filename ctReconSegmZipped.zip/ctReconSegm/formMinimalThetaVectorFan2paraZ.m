function theta = formMinimalThetaVectorFan2paraZ(m,n,dthetaDeg,gammaDeg)
if mod(m,2) == 0%Calculate theta for 'FanCoverage','minimal'
    ibegin = 3;
else
    ibegin = 2;
end
gammaMin = min(gammaDeg(ibegin:end));gammaMax = max(gammaDeg(1:end-1));
theta = formMinimalThetaVector(n,dthetaDeg,gammaMin,gammaMax);
if length(theta) ~= n
    error(message('images:fan2para:badThetaLength'))
end