% Copyright (c) 2009, Sylvain Boltz
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
% DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
% FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
% DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
% CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
% OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
% OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
function [imgsSegmentd,nClasses,time,nEdges,szSegmsQs]=...
    srm4(I,Qlevels,g,minSZ,W1)

tic%Statistical Region Merging on a square lattice with 4-connectivity
% Compute image gradient
W2=1-W1;Ix=zeros(size(I));Iy=zeros(size(I));%x-derivative and y-der. of I
IxL=Ix;IxR=Ix;IyU=Iy;IyD=Iy;
SOBx=[-1,0,1;-2,0,2;-1,0,1]/8;SOBy=SOBx';%Sobel=[-1,9,-45,0,45,-9,1]/60
for i=1:size(I,3)
    Ix(:,:,i)=imfilter(I(:,:,i),SOBx,'replicate');%sob
    tI=I(:,:,i);tIxL=imfilter(tI,[-1,1,0],'replicate');
    tIxL(:,1)=tI(:,2)-tI(:,1);%As the left derivative of the 1st column.
    IxL(:,:,i)=tIxL;
    tIxR=imfilter(tI,[0,-1,1],'replicate');
    tIxR(:,end)=tI(:,end)-tI(:,end-1);%As the right der. of the last col.
    IxR(:,:,i)=tIxR;
    Iy(:,:,i)=imfilter(I(:,:,i),SOBy,'replicate');%sob'
    tIyU=imfilter(tI,[-1,1,0]','replicate');
    tIyU(1,:)=tI(2,:)-tI(1,:);%As the up derivative of the 1st column.
    IyU(:,:,i)=tIyU;
    tIyD=imfilter(tI,[0,-1,1]','replicate');
    tIyD(end,:)=tI(end,:)-tI(end-1,:);%As the right der. of the last col.
    IyD(:,:,i)=tIyD;
end
Ix=max(W1*abs(Ix)+W2*(abs(IxL)+abs(IxR))/2,[],3);
Iy=max(W1*abs(Iy)+W2*(abs(IyU)+abs(IyD))/2,[],3);%Iy=max(abs(Iy),[],3);
Ix(:,end)=[];Iy(end,:)=[];
[~,index]=sort(abs([Iy(:);Ix(:)]));
nQ=numel(Qlevels);imgsSegmentd=cell(nQ,1);%maps=cell(nQ,1);
imSeg=I;imSz=size(I);treerank=zeros(imSz(1:2));imFinal=zeros(imSz);
n=imSz(1)*imSz(2);A=reshape(1:n,imSz(1:2));szSegms=ones(imSz(1:2));

%Building pairs; 
idx2=reshape(A(:,1:end-1),[],1);idx1=reshape(A(1:end-1,:),[],1);
pairs1=[idx1;idx2];pairs2=[idx1+1;idx2+imSz(1)];nEdges=numel(index);
logdelta=2*log(6*n);nClasses=zeros(1,nQ);
for Q=Qlevels
    iter=find(Q==Qlevels);
    for i=1:nEdges
        C1=pairs1(index(i));C2=pairs2(index(i));
        %Union-Find structure, here are the finds, average complexity O(1)
        while (A(C1)~=C1 ); C1=A(C1); end
        while (A(C2)~=C2 ); C2=A(C2); end
        % Compute the predicate, region merging test
        dR=(imSeg(C1)-imSeg(C2))^2;
        dG=(imSeg(C1+n)-imSeg(C2+n))^2;dB=(imSeg(C1+2*n)-imSeg(C2+2*n))^2;        
        dev=g^2*logdelta*(1/szSegms(C1)+1/szSegms(C2))/(2*Q);                
        predicat=((dR<dev)&(dG<dev)&(dB<dev));               
     if (((C1~=C2)&predicat) | szSegms(C1)<=minSZ | szSegms(C2)<=minSZ)
            if treerank(C1)>treerank(C2)%Find the new root for both regions
                A(C2) = C1; reg=C1;regNot=C2;
            elseif treerank(C1) < treerank(C2)
                A(C1) = C2; reg=C2;regNot=C1;
            elseif C1 ~= C2
                A(C2) = C1; reg=C1;regNot=C2;
                treerank(C1) = treerank(C1) + 1;
            end
            if C1~=C2%Merge regions
                nreg=szSegms(C1)+szSegms(C2);
            imSeg(reg)=(szSegms(C1)*imSeg(C1)+szSegms(C2)*imSeg(C2))/nreg;
imSeg(reg+n)=(szSegms(C1)*imSeg(C1+n)+szSegms(C2)*imSeg(C2+n))/nreg;
imSeg(reg+2*n)=(szSegms(C1)*imSeg(C1+2*n)+szSegms(C2)*imSeg(C2+2*n))/nreg;
                szSegms(reg)=nreg;nClasses(1,iter)=nClasses(1,iter)+1;
                szSegms(regNot)=0;
            end
     end%if (((C1~=C2)&predicat) | ...
    end%for i=1:nEdges   
    while 1%To obtain the final class indices for the final filtered image
        map_ = A(A) ;
        if isequal(map_,A) ; break ; end
        A = map_ ;
    end
    for i=1:3
        imFinal(:,:,i)=imSeg(A+(i-1)*n);
    end
    imgsSegmentd{iter}=imFinal;szSegmsOutput=szSegms(:);
    szSegmsOutput=nonzeros(szSegmsOutput);szSegmsQs{iter}=szSegmsOutput';
end%for Q=Qlevels
for t=iter:-1:2,
    tSum=0;
    for j=1:t,
    tSum=tSum+nClasses(1,j);
    end
    nClasses(1,t)=tSum;
end
nClasses=imSz(1)*imSz(2)-nClasses;time=toc;%End of the function srm4