close all;clear all;clc;
[filename,pathname] =...
uigetfile({'*.*';'*.jpg';'*.jpeg';'*.bmp';'*.tif';'*.gif';'*.png'});
Iin = imread([pathname,filename]);%
imL=512;% Iin = phantom('Modified Shepp-Logan',imL);
Iin=double(Iin);ctImF1=double(Iin(:,:,1));

origIm=imresize(ctImF1,[imL,imL],'bilinear');origIm=origIm-min(origIm(:));
origIm=255*origIm/max(origIm(:));
% figure(1),imagesc(origIm);title('Input image for simulating CT recon.');
origIm0=origIm(:,:,1);paddedImL=ceil(imL*sqrt(2))+2;
padNum1=floor((paddedImL-imL)/2);padNum1P1=padNum1+1;adNum1Pn=padNum1+imL;
paddedIm=zeros(paddedImL,paddedImL);
paddedIm(padNum1P1:adNum1Pn,padNum1P1:adNum1Pn)=origIm0;
origIm1=paddedIm;imL=paddedImL;

[Svec,Hvec,Av,Bv,Ah,Bh,S_Sq,SqIndVec,SqIJ2C,HexIndVec,HexIJ2C,mHex,...
    nHex,CenteredA,CenteredB,X,Y]=imResample(origIm1,imL);

S_SqPlot=S_Sq(padNum1P1:adNum1Pn,padNum1P1:adNum1Pn);
figure(1),imagesc(S_SqPlot);title('Input image for simulating CT recon.');
Xplane=[1:imL]-(imL+1)/2;

n_theta=1*180;d_theta=180/n_theta;THETA=linspace(0,180-d_theta,n_theta);
[MatlabRadon,xp]=radon(S_Sq,THETA);m=imL;
n=imL;r=n/2-0.5;c=(n+1)/2;Rsq = radonVec(X(:),Y(:),S_Sq(:),n,THETA);
RsVec = radonVec(Bv,Av,Svec,n,THETA);RhVec = radonVec(Bh,Ah,Hvec,n,THETA);

InterpMethod='pchip';%linear,pchip
filter='ram-lak';%{'ram-lak','shepp-logan','cosine','hamming', 'hann'};
 
tildeMatlabSubsampled = iradon(MatlabRadon,1,filter,n);%linear, pchip
tildeMatlabSubsampled=tildeMatlabSubsampled(padNum1P1:adNum1Pn,padNum1P1:adNum1Pn);
figure(2),imagesc(tildeMatlabSubsampled);
hold on
title('Reconst. IM using built-in Matlab, with subsampling by a factor 2');
hold off

tic
tilde0=iradon2006aZh(Rsq,THETA,InterpMethod,filter,1,n);
Time2dRecon=toc
tilde0=tilde0(padNum1P1:adNum1Pn,padNum1P1:adNum1Pn);
figure(3),imagesc(tilde0);
hold on
title('Reconst. IM using built-in Matlab, no subsampling');
hold off

tic
tildeSvec=iradonVec(RsVec,THETA,filter,1,InterpMethod,n,Bv,Av);
TimeSqVecRecon=toc 
%Resample the vector image tildeSvec to a square image to be displayed
tildeSvecSq=griddata(Bv,Av,tildeSvec,X,Y,'cubic');
tildeSvecSq(isnan(tildeSvecSq))=0;
tildeSvecSq=tildeSvecSq(padNum1P1:adNum1Pn,padNum1P1:adNum1Pn);
figure(4),imagesc(tildeSvecSq);
hold on
title('Resample the reconstructed vec to a square image');
hold off

tic
tildeHvec=iradonVec(RhVec,THETA,filter,1,InterpMethod,n,Bh,Ah);
TimeHexVecRecon=toc 
tildeHsVec=griddata(Bh,Ah,tildeHvec,Bv,Av,'cubic');%To compare with tildeSvec
tildeHsVec(isnan(tildeHsVec))=0;

%Resample the vector image tildeHvec to a square image to be displayed
tildeHrVecSq=griddata(Bh,Ah,tildeHvec,X,Y,'cubic');
tildeHrVecSq(isnan(tildeHrVecSq))=0;
tildeHrVecSq=tildeHrVecSq(padNum1P1:adNum1Pn,padNum1P1:adNum1Pn);

figure(5),imagesc(tildeHrVecSq);
hold on
title('Resample the reconstructed hex image to a square image');
hold off

%Recon errors in terms of L_1 norm with interpl pchip.  randC =0.5.
%The smaller the better.
%Because of the rand coordinates for M_rand, results may vary a bit.
%filter is in {'ram-lak','shepp-logan','cosine','hamming', 'hann'};
disp('L1 norm: the smaller the better');
dfL1_tildeSvec=norm(Svec-tildeSvec,1)      
dfL1_tildeH=norm(Hvec-tildeHvec,1)          
dfL1_tildeHr=norm(Svec-tildeHsVec,1)         

%Recon errors in terms of L_2 norm with interpl linear or pchip.
%The smaller the better.
%Because of the rand coordinates for M_rand, results may vary a bit.
disp('L2 norm: the smaller the better');
dfL2_tildeSvec=norm(Svec-tildeSvec,2)  
dfL2_tildeH=norm(Hvec-tildeHvec,2)   
dfL2_tildeHr=norm(Svec-tildeHsVec,2)  

%Recon errors in terms of Peak signal-to-noise ratio (PSNR) for n=512 
%with interpl linear or pchip, the bigger the better
MSE_tildeSvec=(dfL2_tildeSvec)^2/length(Svec);
PSNR_tildeSvec=10*log10((max(Svec))^2/MSE_tildeSvec)

MSE_tildeH=(dfL2_tildeH)^2/length(Hvec);
PSNR_tildeH=10*log10((max(Hvec))^2/MSE_tildeH)     

MSE_tildeHr=(dfL2_tildeHr)^2/length(Svec);
PSNR_tildeHr=10*log10((max(Svec))^2/MSE_tildeHr)     

%Recon errors in terms of Pearson correlation coefficient. 
%The bigger the better.
%Because of the rand coordinates for M_rand, results may vary a bit.
disp('Pearson correlation coefficient: the bigger the better');
CorrelCoef_tildeSvec=corr2(Svec,tildeSvec)           
CorrelCoef_tildeH=corr2(Hvec,tildeHvec)               
CorrelCoef_tildeHr=corr2(Svec,tildeHsVec)              
figure(6)
Xplot = categorical({'Sq recon','Hex recon','Resample Hex recon to a Sq lattice'});
Xplot = reordercats(Xplot,{'Sq recon','Hex recon','Resample Hex recon to a Sq lattice'});
Yplot = [PSNR_tildeSvec, PSNR_tildeH, PSNR_tildeHr];
b=bar(Xplot,Yplot);b(1).FaceColor = 'Flat'; b(1).CData = [.2 .6 .5];hold on
title('PSNR (dB) of reconstructed images vs sampling schemes');hold off

%%%%%%%%%%%%%%%%%%%%%%Segment the reconstructed images%%%%%%%%%%%%%%%%%%%%
imL=length(tildeSvecSq);imN=zeros(imL,imL,3);imN(:,:,1)=tildeSvecSq;
imN(:,:,2)=tildeSvecSq;imN(:,:,3)=tildeSvecSq;
nPixels=length(Hvec);HexIm=zeros(nPixels,3);
HexIm(:,1)=tildeHvec;HexIm(:,2)=tildeHvec;HexIm(:,3)=tildeHvec;%para
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%inputIm=imN;g=256;minSZ=3;
W1=0.4;g=256;minSZ=3;Qlevels=2.^(6:-1:0);nQ=length(Qlevels);%Q small few segs
[imgsSegmentd,nClassesL4,time,numEdges,szSegmsQs]...
=srm4(imN,Qlevels,g,minSZ,W1);%Segmentat. using sq. lattices with 4-connec.
timeOfSegmBy4Conne=time;numEdgesBy4Conne=numEdges;titleFtSz=11;
tI=imgsSegmentd{nQ};
figure(7),df4ConneNorm1=zeros(1,nQ-1);df4ConneNorm2=zeros(1,nQ-1);
for k=2:nQ,
    tI=imgsSegmentd{k};
    subplot(3,2,k-1),imagesc(uint8(tI));axis off;
   tiHH=title([strcat('Q=',num2str(Qlevels(k)),...
      ', 4-connec: ','{ }', num2str(nClassesL4(k)),' segms')]);
   set(tiHH,'FontSize',titleFtSz);
end
Qpos1=1;outputIm1=imgsSegmentd{Qpos1};outputNum1=nClassesL4(Qpos1);
Qpos1N=nQ;outputIm1N=imgsSegmentd{Qpos1N};outputNum1N=nClassesL4(Qpos1N);
[imgsSegmentd,nClassesL8,time,numEdges,szSegmsQs]...
=srm8(imN,Qlevels,g,minSZ,W1);%Segmentat. using sq. lattices with 8-connec.
timeOfSegmBy8Conne=time;numEdgesBy8Conne=numEdges;tI=imgsSegmentd{nQ};
df8ConneNorm1=zeros(1,nQ-1);df8ConneNorm2=zeros(1,nQ-1);
outputIm2=imgsSegmentd{Qpos1};outputNum2=nClassesL8(Qpos1);
outputIm2N=imgsSegmentd{Qpos1N};outputNum2N=nClassesL8(Qpos1N);
figure(8),
for k=2:nQ
    tI=imgsSegmentd{k};
    subplot(3,2,k-1),imagesc(uint8(tI));axis off;
    tiHH=title([strcat('Q=',num2str(Qlevels(k)),...
        ', 8-connec: ','{ }', num2str(nClassesL8(k)),' segms')]);
    set(tiHH,'FontSize',titleFtSz);
end

[hexImgsSegmentd,nClassesHex,time,numEdges,szSegmsQs]=...
srmHex(HexIm,Qlevels,g,minSZ,W1,mHex,nHex);%Segmentat. using hex. lattices
timeOfSegmByHexConne=time;numEdgesByHexConne=numEdges;
tI=hexImgsSegmentd{nQ};HexIm1=Hvec;%HexIm;%/mean(mean(mean(HexIm)));
tic
for k=1:nQ,
    imFinal=zeros(m,n,3);imFinalHex=hexImgsSegmentd{k};
ImSq1=griddata(CenteredB,CenteredA,imFinalHex(:,1),X,Y);
ImSq1(isnan(ImSq1))= 0;
ImSq2=griddata(CenteredB,CenteredA,imFinalHex(:,2),X,Y);
ImSq2(isnan(ImSq2))= 0;
ImSq3=griddata(CenteredB,CenteredA,imFinalHex(:,3),X,Y);
ImSq3(isnan(ImSq3))= 0;
imFinal(:,:,1)=ImSq1;imFinal(:,:,2)=ImSq2;imFinal(:,:,3)=ImSq3;
imgsSegmentd{k}=imFinal;
end
timeHexResamp=toc
outputIm3=imgsSegmentd{Qpos1};outputNum3=nClassesHex(Qpos1);
outputIm3=outputIm3(padNum1P1:adNum1Pn,padNum1P1:adNum1Pn,:);
outputIm3N=imgsSegmentd{Qpos1N};outputNum3N=nClassesHex(Qpos1N);
outputIm3N=outputIm3N(padNum1P1:adNum1Pn,padNum1P1:adNum1Pn,:);

figure(9),dfHexConneNorm1=zeros(1,nQ-1);dfHexConneNorm2=zeros(1,nQ-1);
for k=2:nQ,
    tI=imgsSegmentd{k};tI=tI(padNum1P1:adNum1Pn,padNum1P1:adNum1Pn,:);
    subplot(3,2,k-1),imagesc(uint8(tI));axis off;
    tiHH=title([strcat('Q=',num2str(Qlevels(k)),...
        ', Hex:','{ }', num2str(nClassesHex(k)),' segms')]);
    set(tiHH,'FontSize',titleFtSz);
end

figure(10),
subplot(2,2,1),imagesc(uint8(origIm0));axis off;
hh=title('The input image');set(hh,'FontSize',titleFtSz);
subplot(2,2,2),imagesc(uint8(outputIm1));axis off;
hh=title([strcat('Q=',num2str(Qlevels(Qpos1)),', 4-connec: ','{ }', ...
    num2str(outputNum1),' segms')]);
set(hh,'FontSize',titleFtSz);
subplot(2,2,3),imagesc(uint8(outputIm2));axis off;
hh=title([strcat('Q=',num2str(Qlevels(Qpos1)),', 8-connec: ','{ }', ...
    num2str(outputNum2),' segms')]);
set(hh,'FontSize',titleFtSz);
subplot(2,2,4),imagesc(uint8(outputIm3));axis off;
hh=title([strcat('Q=',num2str(Qlevels(Qpos1)),', Hex-connec: ','{ }', ...
    num2str(outputNum3),' segms')]);
set(hh,'FontSize',titleFtSz);

figure(11),
subplot(2,2,1),imagesc(uint8(origIm0));axis off;
hh=title('The input image');set(hh,'FontSize',titleFtSz);
subplot(2,2,2),imagesc(uint8(outputIm1N));axis off;
hh=title([strcat('Q=',num2str(Qlevels(Qpos1N)),', 4-connec: ','{ }', ...
    num2str(outputNum1N),' segms')]);
set(hh,'FontSize',titleFtSz);
subplot(2,2,3),imagesc(uint8(outputIm2N));axis off;
hh=title([strcat('Q=',num2str(Qlevels(Qpos1N)),', 8-connec: ','{ }', ...
    num2str(outputNum2N),' segms')]);
set(hh,'FontSize',titleFtSz);
subplot(2,2,4),imagesc(uint8(outputIm3N));axis off;
hh=title([strcat('Q=',num2str(Qlevels(Qpos1N)),', Hex-connec: ','{ }', ...
    num2str(outputNum3N),' segms')]);
set(hh,'FontSize',titleFtSz);

% Segment a sample 2D image into 3 classes using fuzzy c-means algorithm.
im=origIm0;%im=imN;
im=im(:,:,1);im=im-min(min(im));im=255*im/max(max(im));im=uint8(im);
numComponents=11;%outputNum3
[C,U,LUT,H]=FastFCMeans(im,numComponents);Umap=FM2map(im,U,H);
figure(12),subplot(3,4,1), imshow(im);
set(get(gca,'Title'),'String','The input image');
for i=1:numComponents,
    subplot(3,4,i+1), 
    imshow(Umap(:,:,i))
    ttl=sprintf('Segmented Class %d',i);
    set(get(gca,'Title'),'String',ttl)
end