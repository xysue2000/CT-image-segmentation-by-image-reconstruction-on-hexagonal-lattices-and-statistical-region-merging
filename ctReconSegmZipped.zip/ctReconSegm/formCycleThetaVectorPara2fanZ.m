function theta = formCycleThetaVectorPara2fanZ(dthetaDeg);
if mod(360,dthetaDeg) ~= 0    
    error(message('images:para2fan:dthetaNotFactorOf360'));
end
theta = 0:dthetaDeg:(360-dthetaDeg);