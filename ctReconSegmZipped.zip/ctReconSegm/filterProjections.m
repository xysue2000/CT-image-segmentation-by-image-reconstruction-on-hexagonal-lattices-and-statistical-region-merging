function [p,sino,Hk,hn]=...
    filterProjections(Pin,filter,DTA,SOD,SDD,fSensorSp,extra);

Pin = Pin.*(cos(DTA)*SOD);p = Pin; 
[sino,Hk,hn,nn,g]=fbp_sino_filter(p,fSensorSp,SDD,filter,extra);
len = size(p,1);H = designFilter(filter, len, 1);
if strcmpi(filter, 'none')
return;
end

p(length(H),1)=0;                       % Zero pad projections
p = fft(p);                             % p holds fft of projections

for i = 1:size(p,2),% frequency domain filtering
p(:,i)=p(:,i).*H.*0.5*(fSensorSp/sin(fSensorSp)^2);
end

p = real(ifft(p));                      % p is the filtered projections
p(len+1:end,:) = [];                    % Truncate the filtered projections
end 