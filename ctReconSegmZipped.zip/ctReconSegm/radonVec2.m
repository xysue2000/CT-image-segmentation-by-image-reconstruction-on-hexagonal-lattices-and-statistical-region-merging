function [RT] = radonVec2(A_h,B_h,H,n,THETA);
%n is the radius of the inscribed circle
b = ceil((sqrt(2)*n)/2 + 1);xp = [-b:b]';sz = size(xp);X=B_h';Y=-A_h';
H = H';th = THETA*pi/180;RT=zeros(length(xp),length(THETA));
for l=1:length(THETA),
    angle=th(l);Xp = cos(angle) * X + sin(angle) * Y;
    ip = Xp + b + 1;k = floor(ip);frac = ip-k;
    RT(:,l) = accumarray(k',H.*(1-frac),sz) + accumarray(k'+1,H.*frac,sz);
end