function Umap=FM2map(im,U,H)
Umap=zeros(sum(H),size(U,2));
i1=1; i2=0;
for i=1:numel(H)
    i2=i2+H(i);Umap(i1:i2,:)=repmat(U(i,:),[H(i) 1]);i1=i2+1;
end
[~,idx]=sort(im(:), 'ascend');[~,idx]=sort(idx(:),'ascend');
Umap=reshape(Umap(idx,:),[size(im) size(U,2)]);

