function A = setNaNsToZero(A);

A(isnan(A)) = 0;