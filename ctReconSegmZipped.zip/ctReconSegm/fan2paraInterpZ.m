function P =fan2paraInterpZ(F,d,...
    gammaDeg,thetaDeg,ploc,pthetaDeg,interp,isFanCoverageCycle);

[m,n] = size(F);
if isFanCoverageCycle%use full 360-deg fan-beam set to get 180-deg p-beam
    n4 = ceil(n/4); % first reconstruction
    Fpad = [ F(:,end-n4+1:end) F ];   % exploit periodicity of sinogram
    thetapad = [ thetaDeg(end-n4+1:end)-360 thetaDeg ];  
    P = fan2paraInterpZ(Fpad,d,gammaDeg,thetapad,...
                       ploc,pthetaDeg,interp,false);
else
    numelPtheta = numel(pthetaDeg);
   
% shift to correct for fan-beam angles and interp to desired p-beam angles
    Fsh = zeros(m,numelPtheta);
    for i=1:m,
        Fsh(i,:) = interp1(thetaDeg-gammaDeg(i),F(i,:),pthetaDeg,interp); 
    end

% interpolate to get desired p-beam sample locations
% t = d*sin(gammaRad) = distance of projection sample (beam) to iso-center
    numelPloc = numel(ploc);P = zeros(numelPloc,numelPtheta);
    t = d*sin(gammaDeg*pi/180); % t approximates fan beam as parallel beam.    
    for i=1:numelPtheta
        P(:,i) = interp1(t,Fsh(:,i)',ploc,interp)';
    end
end
P = setNaNsToZero(P);