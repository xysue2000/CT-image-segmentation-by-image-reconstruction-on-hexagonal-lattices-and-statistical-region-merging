% Copyright (c)
% https://github.com/kk17m/CT-Fan-beam-FBP-reconstruction
function [sino,Hk,hn,nn,g]=fbp_sino_filter(sino,ds,dsd,window,extra)

[nb,na]=size(sino);npad=2^ceil(log2(2*nb-1));
sino=[sino;zeros(npad-nb,na)];%[hn,nn] = fbp_ramp(type, npad, ds, dsd);
nn=[-(npad/2):(npad/2-1)]';h=zeros(size(nn));h(nn==0)=1/(4*ds^2);
odd=mod(nn,2)==1;h(odd) = -1 ./(pi*sin(nn(odd)*ds)).^2;g=h/2;hn=h;
Hk=real(fft(fftshift(g)));Hk=Hk .*fbp2_window(npad,window);Hk=ds*Hk; 
sino = ifft( fft(sino, [], 1) .* repmat(Hk, [1 na]), [], 1, 'symmetric');
sino = sino([1:(nb+extra)],:);sino([(nb+1):(nb+extra)],:) = 0;
sino=real(sino);