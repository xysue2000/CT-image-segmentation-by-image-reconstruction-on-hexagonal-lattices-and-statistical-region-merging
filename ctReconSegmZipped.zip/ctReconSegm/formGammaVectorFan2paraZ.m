function gammaDeg=formGammaVectorFan2paraZ(m,d,fanSpacing,fanSensorGeometry);
m2cn=floor((m-1)/2);m2cp=floor(m/2);g=(-m2cn:m2cp)*fanSpacing;
if strcmp(fanSensorGeometry,'line') | strcmp(fanSensorGeometry,'Line')
%g represents linear spacing along the line perpendicular to central beam
%so the set of angles gammaDeg must be calculated using ATAN.
    gammaDeg = atan(g/d)*180/pi;
else % strcmp(fanSensorGeometry,'arc')
    gammaDeg = g;
end

