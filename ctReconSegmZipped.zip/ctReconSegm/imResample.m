function [Svec,Hvec,As,Bs,Ah,Bh,S_Sq,SqIndVec,SqIJ2C,HexIndVec,HexIJ2C,...
    mHex,nHex,CenteredA,CenteredB,xx,yy]=imResample(I,imL);

Rn=(imL-1)/2;Inois=I;%Inois=imnoise(I,'gaussian'); imL is the length of I
As=zeros(imL^2,1);Bs=zeros(imL^2,1);c=(imL+1)/2;randC=0;%randC=1.98;
AsRand=As;BsRand=Bs;%AsRand and BsRand are for lattice 
%points of the sq. lattice with randomization in the circular region
SqIndVec=zeros(imL^2,2);SqIJ2C=zeros(imL,imL);count=0;
for ii=1:imL,
    for jj=1:imL,
            count=count+1;As(count,1)=ii-c;Bs(count,1)=jj-c;
            AsRand(count,1)=ii-c+randC*(rand-0.5);
            BsRand(count,1)=jj-c+randC*(rand-0.5);
            SqIndVec(count,:)=[ii,jj];SqIJ2C(ii,jj)=count;            
    end
end
% As=As(1:count,1);Bs=Bs(1:count,1);
L_SqCir=count;
% AsRand=AsRand(1:count,1);BsRand=BsRand(1:count,1);
SqIndVec=SqIndVec(1:count,:);% countSq=count 

a=2/sqrt(3);s=sqrt(a);B1=s*[1,0];B2=s*[-1/2,sqrt(3)/2];
%s makes the area of a Voronoi cell of the hex lattice gen. by B1 and B2 is 1
%so that the hex lattice and usual sq. lattice have the same sampling rate

mHex=ceil(imL/s);nHex=ceil(2*imL/(s*sqrt(3)));
if mod(nHex,2)==0,
    centerHexIJ=[(2*mHex+nHex-2)/4+2/3,nHex/2+1/3];
    centerHexXY=((2*mHex+nHex-2)/4+2/3)*B1+(nHex/2+1/3)*B2;
    nPixels=nHex*(2*mHex-1)/2;HexIJ2C=zeros(mHex-1+nHex/2,nHex);
else,%mod(nHex,2)==1
    centerHexIJ=[(2*mHex+nHex+1)/4,(nHex+1)/2];
    centerHexXY=((2*mHex+nHex+1)/4)*B1+((nHex+1)/2)*B2;
    nPixels=mHex+(nHex-1)*(2*mHex-1)/2;HexIJ2C=zeros(mHex+(nHex-1)/2,nHex);
end

Ah=zeros(nPixels,1);Bh=zeros(nPixels,1);HexIndVec=zeros(nPixels,2);count=0; 
for jj=1:nHex,
    vec2=jj*B2;
    if mod(jj,2)==1,
        jh=(jj-1)/2;
        for ii=(1+jh):(mHex+jh),
            vec1=ii*B1;point=vec1+vec2;count=count+1;
            Ah(count,1)=point(1,1);Bh(count,1)=point(1,2);
            HexIndVec(count,:)=[ii,jj];HexIJ2C(ii,jj)=count;
        end
    else,%mod(jj,2)==0,
        jh=jj/2;
        for ii=(1+jh):(mHex+jh-1),
            vec1=ii*B1;point=vec1+vec2;count=count+1;
            Ah(count,1)=point(1,1);Bh(count,1)=point(1,2);
            HexIndVec(count,:)=[ii,jj];HexIJ2C(ii,jj)=count;
        end
    end
end
CenteredA=Ah-centerHexXY(1,1);CenteredB=Bh-centerHexXY(1,2);
[xx,yy]=meshgrid([1:imL]-c);%xx and yy are for coordinates of I
xxVec=xx(:);yyVec=yy(:);InoisVec=Inois(:);
Fnois = scatteredInterpolant(xxVec,yyVec,InoisVec,'natural','none');%linear
M_rand=Fnois(BsRand,AsRand);M_rand(isnan(M_rand))= 0;%For interpol.  
% F_Rand=scatteredInterpolant(BsRand(:),AsRand(:),M_rand(:),'natural','none');
F_Rand=scatteredInterpolant(BsRand,AsRand,M_rand,'natural','none');
Svec=F_Rand(Bs,As);Svec(isnan(Svec))= 0;
S_Sq=F_Rand(xx,yy);S_Sq(isnan(S_Sq))= 0;%S_Sq=F_Rand(xx,yy);
AhCentered=Ah-centerHexXY(1,1);BhCentered=Bh-centerHexXY(1,2);
Ah=AhCentered;Bh=BhCentered;
Hvec=F_Rand(Bh,Ah);Hvec(isnan(Hvec))= 0;
% Svec=max(Svec,0);Hvec=max(Hvec,0);S_Sq=max(S_Sq,0);