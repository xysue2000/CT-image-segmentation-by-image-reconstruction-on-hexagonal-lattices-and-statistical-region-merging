function [P,oploc,optheta]=fan2paraZ(F,d,FanSensorSpacing,...
    ParallelSensorSpacing,FanSensorGeometry,Interpolation,...
    FanCoverage,FanRotationIncrement,ParallelCoverage); 

[F,m] = padToOddDim(F);fanSpacing = FanSensorSpacing;
gammaDeg=formGammaVectorFan2paraZ(m,d,fanSpacing,FanSensorGeometry);
n = size(F,2);%FAN2PARA Convert fan-beam projections to parallel-beam
if strcmp(FanCoverage,'minimal')
    isFanCoverageCycle = false;
    dthetaDeg = FanRotationIncrement;
    gammaMin=min(gammaDeg);gammaMax=max(gammaDeg);
thetaDeg = formMinimalThetaVectorFan2paraZ(m,n,dthetaDeg,gammaDeg);
    F = F(2:end-1,:);gammaDeg = gammaDeg(2:end-1);
else
    isFanCoverageCycle = true;thetaDeg =(0:n-1)*360/n;
end
    
ploc = formPlocVectorFan2paraZ(d,gammaDeg,ParallelSensorSpacing);
ParallelRotationIncrement=FanRotationIncrement;
dpthetaDeg = ParallelRotationIncrement;
pthetaDeg = formPthetaVectorFan2paraZ(dpthetaDeg,ParallelCoverage);
P = fan2paraInterpZ(F,d,...
                   gammaDeg,thetaDeg,ploc,pthetaDeg,...
                   Interpolation,...
                   isFanCoverageCycle);
oploc = ploc';optheta = pthetaDeg;