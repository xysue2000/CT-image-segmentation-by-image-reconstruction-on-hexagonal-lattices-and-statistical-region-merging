function [PCycle,pthetaCycle] = repPforCycleCoverage(P,ptheta)

PCycle = [P flipud(P)];pthetaCycle = [ptheta, ptheta+180];